// StudyHub - Student Study Platform JavaScript

class StudyHub {
    constructor() {
        this.currentSection = 'dashboard';
        this.currentNoteId = null;
        this.currentQuizId = null;
        this.currentDeckId = null;
        this.currentCardIndex = 0;
        this.currentQuestionIndex = 0;
        this.quizAnswers = [];
        this.timerInterval = null;
        this.timerRunning = false;
        this.timerMode = 'focus'; // 'focus' or 'break'
        this.timeRemaining = 25 * 60; // 25 minutes in seconds
        this.sessionsCompleted = 0;
        this.totalFocusTime = 0;

        // Sample data
        this.subjects = ["Mathematics", "Chemistry", "Physics", "Biology", "History", "English", "Spanish", "Computer Science"];
        this.tasks = [
            {
                id: 1,
                title: "Complete Chemistry Lab Report",
                subject: "Chemistry",
                priority: "high",
                dueDate: "2025-08-25",
                completed: false,
                description: "Write lab report on titration experiment"
            },
            {
                id: 2,
                title: "Study for Math Quiz",
                subject: "Mathematics",
                priority: "medium",
                dueDate: "2025-08-24",
                completed: false,
                description: "Review calculus chapters 5-7"
            },
            {
                id: 3,
                title: "Read History Chapter 12",
                subject: "History",
                priority: "low",
                dueDate: "2025-08-26",
                completed: true,
                description: "World War II timeline"
            }
        ];

        this.flashcardDecks = [
            {
                id: 1,
                name: "Biology - Cell Structure",
                cards: [
                    {front: "What is the powerhouse of the cell?", back: "Mitochondria"},
                    {front: "What controls what enters and exits the cell?", back: "Cell membrane"},
                    {front: "Where is DNA stored in eukaryotic cells?", back: "Nucleus"}
                ]
            },
            {
                id: 2,
                name: "Spanish Vocabulary",
                cards: [
                    {front: "Hello", back: "Hola"},
                    {front: "Thank you", back: "Gracias"},
                    {front: "Goodbye", back: "Adiós"}
                ]
            }
        ];

        this.notes = [
            {
                id: 1,
                title: "Physics - Newton's Laws",
                subject: "Physics",
                content: "1. First Law: An object at rest stays at rest...\n2. Second Law: F = ma\n3. Third Law: For every action there is an equal and opposite reaction",
                tags: ["physics", "mechanics", "laws"],
                dateCreated: "2025-08-20"
            },
            {
                id: 2,
                title: "Literature - Shakespeare Themes",
                subject: "English",
                content: "Common themes in Shakespeare:\n- Love and romance\n- Power and ambition\n- Fate vs free will\n- Appearance vs reality",
                tags: ["literature", "shakespeare", "themes"],
                dateCreated: "2025-08-19"
            }
        ];

        this.quizzes = [
            {
                id: 1,
                title: "Biology Quiz - Cells",
                questions: [
                    {
                        question: "What is photosynthesis?",
                        type: "multiple",
                        options: ["Process of making food from sunlight", "Cell division", "Protein synthesis", "DNA replication"],
                        correct: 0
                    },
                    {
                        question: "Chloroplasts are found in plant cells.",
                        type: "boolean",
                        correct: true
                    }
                ]
            }
        ];

        this.events = [
            {
                id: 1,
                title: "Math Exam",
                date: "2025-08-30",
                time: "10:00",
                type: "exam",
                subject: "Mathematics"
            },
            {
                id: 2,
                title: "Study Group - Chemistry",
                date: "2025-08-25",
                time: "15:00",
                type: "study",
                subject: "Chemistry"
            }
        ];
    }

    init() {
        // Wait for DOM to be fully loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                this.setupApplication();
            });
        } else {
            this.setupApplication();
        }
    }

    setupApplication() {
        this.loadFromStorage();
        this.setupEventListeners();
        this.populateSubjectSelects();
        this.updateTimerDisplay();
        this.showSection('dashboard'); // Ensure dashboard is shown initially
    }

    loadFromStorage() {
        try {
            const savedTasks = localStorage.getItem('studyhub_tasks');
            if (savedTasks) {
                this.tasks = JSON.parse(savedTasks);
            }

            const savedNotes = localStorage.getItem('studyhub_notes');
            if (savedNotes) {
                this.notes = JSON.parse(savedNotes);
            }

            const savedDecks = localStorage.getItem('studyhub_decks');
            if (savedDecks) {
                this.flashcardDecks = JSON.parse(savedDecks);
            }

            const savedEvents = localStorage.getItem('studyhub_events');
            if (savedEvents) {
                this.events = JSON.parse(savedEvents);
            }

            const savedQuizzes = localStorage.getItem('studyhub_quizzes');
            if (savedQuizzes) {
                this.quizzes = JSON.parse(savedQuizzes);
            }
        } catch (e) {
            console.error('Error loading from storage:', e);
        }
    }

    saveToStorage() {
        try {
            localStorage.setItem('studyhub_tasks', JSON.stringify(this.tasks));
            localStorage.setItem('studyhub_notes', JSON.stringify(this.notes));
            localStorage.setItem('studyhub_decks', JSON.stringify(this.flashcardDecks));
            localStorage.setItem('studyhub_events', JSON.stringify(this.events));
            localStorage.setItem('studyhub_quizzes', JSON.stringify(this.quizzes));
        } catch (e) {
            console.error('Error saving to storage:', e);
        }
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.getAttribute('data-section');
                this.showSection(section);
            });
        });

        // Theme toggle
        const themeToggle = document.querySelector('.theme-toggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.toggleTheme();
            });
        }

        // Task management
        const addTaskBtn = document.getElementById('add-task-btn');
        if (addTaskBtn) {
            addTaskBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.showTaskModal();
            });
        }

        const saveTaskBtn = document.getElementById('save-task');
        if (saveTaskBtn) {
            saveTaskBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.saveTask();
            });
        }

        const cancelTaskBtn = document.getElementById('cancel-task');
        if (cancelTaskBtn) {
            cancelTaskBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.hideModal();
            });
        }

        // Event management
        const addEventBtn = document.getElementById('add-event-btn');
        if (addEventBtn) {
            addEventBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.showEventModal();
            });
        }

        const saveEventBtn = document.getElementById('save-event');
        if (saveEventBtn) {
            saveEventBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.saveEvent();
            });
        }

        const cancelEventBtn = document.getElementById('cancel-event');
        if (cancelEventBtn) {
            cancelEventBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.hideModal();
            });
        }

        // Flashcard management
        const createDeckBtn = document.getElementById('create-deck-btn');
        if (createDeckBtn) {
            createDeckBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.createDeck();
            });
        }

        const exitStudyBtn = document.getElementById('exit-study');
        if (exitStudyBtn) {
            exitStudyBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.exitStudyMode();
            });
        }

        const flipCardBtn = document.getElementById('flip-card');
        if (flipCardBtn) {
            flipCardBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.flipCard();
            });
        }

        const knowCardBtn = document.getElementById('know-card');
        if (knowCardBtn) {
            knowCardBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.nextCard(true);
            });
        }

        const dontKnowCardBtn = document.getElementById('dont-know-card');
        if (dontKnowCardBtn) {
            dontKnowCardBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.nextCard(false);
            });
        }

        // Timer controls
        const startTimerBtn = document.getElementById('start-timer');
        if (startTimerBtn) {
            startTimerBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.startTimer();
            });
        }

        const pauseTimerBtn = document.getElementById('pause-timer');
        if (pauseTimerBtn) {
            pauseTimerBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.pauseTimer();
            });
        }

        const resetTimerBtn = document.getElementById('reset-timer');
        if (resetTimerBtn) {
            resetTimerBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.resetTimer();
            });
        }

        // Notes
        const addNoteBtn = document.getElementById('add-note-btn');
        if (addNoteBtn) {
            addNoteBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.createNote();
            });
        }

        const notesSearch = document.getElementById('notes-search');
        if (notesSearch) {
            notesSearch.addEventListener('input', this.searchNotes.bind(this));
        }

        // Quiz management
        const createQuizBtn = document.getElementById('create-quiz-btn');
        if (createQuizBtn) {
            createQuizBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.createQuiz();
            });
        }

        // Modal close buttons
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                this.hideModal();
            });
        });

        // Task filters
        const taskFilter = document.getElementById('task-filter');
        if (taskFilter) {
            taskFilter.addEventListener('change', this.filterTasks.bind(this));
        }

        const subjectFilter = document.getElementById('subject-filter');
        if (subjectFilter) {
            subjectFilter.addEventListener('change', this.filterTasks.bind(this));
        }
    }

    showSection(section) {
        console.log('Switching to section:', section);
        
        // Hide all sections
        document.querySelectorAll('.content-section').forEach(s => {
            s.classList.remove('active');
        });
        
        // Remove active class from all nav links
        document.querySelectorAll('.nav-link').forEach(l => {
            l.classList.remove('active');
        });

        // Show selected section
        const sectionElement = document.getElementById(section);
        if (sectionElement) {
            sectionElement.classList.add('active');
        }

        // Add active class to current nav link
        const navLink = document.querySelector(`[data-section="${section}"]`);
        if (navLink) {
            navLink.classList.add('active');
        }

        this.currentSection = section;

        // Render section content
        switch (section) {
            case 'dashboard':
                this.renderDashboard();
                break;
            case 'tasks':
                this.renderTasks();
                break;
            case 'calendar':
                this.renderCalendar();
                break;
            case 'flashcards':
                this.renderFlashcards();
                break;
            case 'notes':
                this.renderNotes();
                break;
            case 'analytics':
                // Delay chart rendering to ensure canvas is visible
                setTimeout(() => this.renderAnalytics(), 100);
                break;
            case 'quizzes':
                this.renderQuizzes();
                break;
        }
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-color-scheme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-color-scheme', newTheme);
        
        const btn = document.querySelector('.theme-toggle');
        if (btn) {
            btn.innerHTML = newTheme === 'dark' ? '<i class="fas fa-sun"></i> Light Mode' : '<i class="fas fa-moon"></i> Dark Mode';
        }
    }

    populateSubjectSelects() {
        const selects = ['task-subject', 'event-subject', 'subject-filter'];
        selects.forEach(selectId => {
            const select = document.getElementById(selectId);
            if (select) {
                // Clear existing options
                select.innerHTML = '';
                
                if (selectId === 'subject-filter') {
                    const allOption = document.createElement('option');
                    allOption.value = 'all';
                    allOption.textContent = 'All Subjects';
                    select.appendChild(allOption);
                }
                
                this.subjects.forEach(subject => {
                    const option = document.createElement('option');
                    option.value = subject;
                    option.textContent = subject;
                    select.appendChild(option);
                });
            }
        });
    }

    // Dashboard Methods
    renderDashboard() {
        const tasksContainer = document.getElementById('dashboard-tasks');
        if (!tasksContainer) return;
        
        const recentTasks = this.tasks.slice(0, 3);
        
        tasksContainer.innerHTML = recentTasks.map(task => `
            <div class="task-item">
                <div class="task-checkbox ${task.completed ? 'completed' : ''}" onclick="app.toggleTask(${task.id})">
                    ${task.completed ? '<i class="fas fa-check"></i>' : ''}
                </div>
                <div class="task-content">
                    <div class="task-title ${task.completed ? 'completed' : ''}">${task.title}</div>
                    <div class="task-meta">
                        <span>${task.subject}</span>
                        <span class="task-priority ${task.priority}">${task.priority}</span>
                    </div>
                </div>
            </div>
        `).join('');
    }

    // Task Management Methods
    renderTasks() {
        const tasksContainer = document.getElementById('tasks-list');
        if (!tasksContainer) return;
        
        const filteredTasks = this.getFilteredTasks();
        
        tasksContainer.innerHTML = filteredTasks.map(task => `
            <div class="task-item">
                <div class="task-checkbox ${task.completed ? 'completed' : ''}" onclick="app.toggleTask(${task.id})">
                    ${task.completed ? '<i class="fas fa-check"></i>' : ''}
                </div>
                <div class="task-content">
                    <div class="task-title ${task.completed ? 'completed' : ''}">${task.title}</div>
                    <div class="task-meta">
                        <span>${task.subject}</span>
                        <span class="task-priority ${task.priority}">${task.priority}</span>
                        <span>${task.dueDate}</span>
                    </div>
                </div>
                <div class="task-actions">
                    <button class="task-action" onclick="app.editTask(${task.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="task-action" onclick="app.deleteTask(${task.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }

    getFilteredTasks() {
        const filter = document.getElementById('task-filter')?.value || 'all';
        const subjectFilter = document.getElementById('subject-filter')?.value || 'all';
        
        return this.tasks.filter(task => {
            const matchesFilter = filter === 'all' || 
                (filter === 'pending' && !task.completed) ||
                (filter === 'completed' && task.completed) ||
                (filter === 'high' && task.priority === 'high');
            
            const matchesSubject = subjectFilter === 'all' || task.subject === subjectFilter;
            
            return matchesFilter && matchesSubject;
        });
    }

    filterTasks() {
        this.renderTasks();
    }

    showTaskModal(taskId = null) {
        const modal = document.getElementById('task-modal');
        const title = document.getElementById('task-modal-title');
        
        if (taskId) {
            const task = this.tasks.find(t => t.id === taskId);
            if (task) {
                title.textContent = 'Edit Task';
                document.getElementById('task-title').value = task.title;
                document.getElementById('task-subject').value = task.subject;
                document.getElementById('task-priority').value = task.priority;
                document.getElementById('task-due-date').value = task.dueDate;
                document.getElementById('task-description').value = task.description || '';
            }
        } else {
            title.textContent = 'Add Task';
            document.getElementById('task-form').reset();
        }
        
        modal.dataset.taskId = taskId || '';
        modal.classList.remove('hidden');
    }

    saveTask() {
        const modal = document.getElementById('task-modal');
        const taskId = modal.dataset.taskId;
        const formData = {
            title: document.getElementById('task-title').value,
            subject: document.getElementById('task-subject').value,
            priority: document.getElementById('task-priority').value,
            dueDate: document.getElementById('task-due-date').value,
            description: document.getElementById('task-description').value,
        };

        if (!formData.title) {
            alert('Please enter a task title');
            return;
        }

        if (taskId) {
            const taskIndex = this.tasks.findIndex(t => t.id === parseInt(taskId));
            if (taskIndex !== -1) {
                this.tasks[taskIndex] = { ...this.tasks[taskIndex], ...formData };
            }
        } else {
            const newTask = {
                id: Date.now(),
                completed: false,
                ...formData
            };
            this.tasks.push(newTask);
        }

        this.saveToStorage();
        this.hideModal();
        this.renderTasks();
        if (this.currentSection === 'dashboard') {
            this.renderDashboard();
        }
    }

    editTask(taskId) {
        this.showTaskModal(taskId);
    }

    deleteTask(taskId) {
        if (confirm('Are you sure you want to delete this task?')) {
            this.tasks = this.tasks.filter(t => t.id !== taskId);
            this.saveToStorage();
            this.renderTasks();
            if (this.currentSection === 'dashboard') {
                this.renderDashboard();
            }
        }
    }

    toggleTask(taskId) {
        const task = this.tasks.find(t => t.id === taskId);
        if (task) {
            task.completed = !task.completed;
            this.saveToStorage();
            this.renderTasks();
            if (this.currentSection === 'dashboard') {
                this.renderDashboard();
            }
        }
    }

    // Calendar Methods
    renderCalendar() {
        const calendarGrid = document.getElementById('calendar-grid');
        const currentWeek = document.getElementById('current-week');
        
        if (!calendarGrid || !currentWeek) return;
        
        const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        const today = new Date();
        
        currentWeek.textContent = `Week of ${today.toLocaleDateString()}`;
        
        calendarGrid.innerHTML = days.map(day => `
            <div class="calendar-day">
                <div class="day-header">${day}</div>
                <div class="day-events">
                    ${this.getEventsForDay(day).map(event => `
                        <div class="calendar-event">${event.title}</div>
                    `).join('')}
                </div>
            </div>
        `).join('');
    }

    getEventsForDay(day) {
        return this.events.filter(event => Math.random() > 0.7);
    }

    showEventModal() {
        const modal = document.getElementById('event-modal');
        document.getElementById('event-form').reset();
        modal.classList.remove('hidden');
    }

    saveEvent() {
        const formData = {
            id: Date.now(),
            title: document.getElementById('event-title').value,
            date: document.getElementById('event-date').value,
            time: document.getElementById('event-time').value,
            type: document.getElementById('event-type').value,
            subject: document.getElementById('event-subject').value
        };

        if (!formData.title) {
            alert('Please enter an event title');
            return;
        }

        this.events.push(formData);
        this.saveToStorage();
        this.hideModal();
        this.renderCalendar();
    }

    // Flashcard Methods
    renderFlashcards() {
        const decksContainer = document.getElementById('flashcard-decks');
        if (!decksContainer) return;
        
        decksContainer.innerHTML = this.flashcardDecks.map(deck => `
            <div class="deck-card" onclick="app.startStudyMode(${deck.id})">
                <div class="deck-title">${deck.name}</div>
                <div class="deck-stats">
                    <span>${deck.cards.length} cards</span>
                    <span>Study</span>
                </div>
            </div>
        `).join('');
    }

    createDeck() {
        const name = prompt('Enter deck name:');
        if (name) {
            const newDeck = {
                id: Date.now(),
                name: name,
                cards: []
            };
            this.flashcardDecks.push(newDeck);
            this.saveToStorage();
            this.renderFlashcards();
        }
    }

    startStudyMode(deckId) {
        this.currentDeckId = deckId;
        this.currentCardIndex = 0;
        const deck = this.flashcardDecks.find(d => d.id === deckId);
        
        if (!deck || deck.cards.length === 0) {
            alert('This deck has no cards. Add some cards first!');
            return;
        }

        document.getElementById('flashcard-decks').classList.add('hidden');
        document.getElementById('study-mode').classList.remove('hidden');
        document.getElementById('deck-title').textContent = deck.name;
        
        this.showCurrentCard();
    }

    showCurrentCard() {
        const deck = this.flashcardDecks.find(d => d.id === this.currentDeckId);
        if (!deck) return;
        
        const card = deck.cards[this.currentCardIndex];
        
        document.getElementById('card-front').textContent = card.front;
        document.getElementById('card-back').textContent = card.back;
        document.getElementById('card-counter').textContent = `${this.currentCardIndex + 1} / ${deck.cards.length}`;
        
        document.getElementById('current-card').classList.remove('flipped');
    }

    flipCard() {
        document.getElementById('current-card').classList.toggle('flipped');
    }

    nextCard(known) {
        const deck = this.flashcardDecks.find(d => d.id === this.currentDeckId);
        if (!deck) return;
        
        if (this.currentCardIndex < deck.cards.length - 1) {
            this.currentCardIndex++;
            this.showCurrentCard();
        } else {
            alert('Deck completed! Great job!');
            this.exitStudyMode();
        }
    }

    exitStudyMode() {
        document.getElementById('study-mode').classList.add('hidden');
        document.getElementById('flashcard-decks').classList.remove('hidden');
    }

    // Timer Methods
    updateTimerDisplay() {
        const minutes = Math.floor(this.timeRemaining / 60);
        const seconds = this.timeRemaining % 60;
        
        const timeDisplay = document.getElementById('time-display');
        const sessionsDisplay = document.getElementById('sessions-completed');
        const focusTimeDisplay = document.getElementById('total-focus-time');
        
        if (timeDisplay) {
            timeDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }
        if (sessionsDisplay) {
            sessionsDisplay.textContent = this.sessionsCompleted;
        }
        if (focusTimeDisplay) {
            focusTimeDisplay.textContent = this.totalFocusTime;
        }
    }

    startTimer() {
        if (!this.timerRunning) {
            this.timerRunning = true;
            this.timerInterval = setInterval(() => {
                this.timeRemaining--;
                this.updateTimerDisplay();
                
                if (this.timeRemaining <= 0) {
                    this.timerComplete();
                }
            }, 1000);
            
            const startBtn = document.getElementById('start-timer');
            if (startBtn) {
                startBtn.textContent = 'Running...';
            }
        }
    }

    pauseTimer() {
        this.timerRunning = false;
        clearInterval(this.timerInterval);
        const startBtn = document.getElementById('start-timer');
        if (startBtn) {
            startBtn.textContent = 'Start';
        }
    }

    resetTimer() {
        this.pauseTimer();
        const focusTime = parseInt(document.getElementById('focus-time')?.value) || 25;
        const breakTime = parseInt(document.getElementById('break-time')?.value) || 5;
        
        this.timeRemaining = this.timerMode === 'focus' ? focusTime * 60 : breakTime * 60;
        this.updateTimerDisplay();
    }

    timerComplete() {
        this.pauseTimer();
        
        if (this.timerMode === 'focus') {
            this.sessionsCompleted++;
            this.totalFocusTime += parseInt(document.getElementById('focus-time')?.value) || 25;
            this.timerMode = 'break';
            const timerLabel = document.getElementById('timer-label');
            if (timerLabel) {
                timerLabel.textContent = 'Break Time';
            }
            alert('Focus session complete! Time for a break.');
        } else {
            this.timerMode = 'focus';
            const timerLabel = document.getElementById('timer-label');
            if (timerLabel) {
                timerLabel.textContent = 'Focus Time';
            }
            alert('Break time over! Ready for another focus session?');
        }
        
        this.resetTimer();
    }

    // Notes Methods
    renderNotes() {
        const notesList = document.getElementById('notes-list');
        if (!notesList) return;
        
        notesList.innerHTML = this.notes.map(note => `
            <div class="note-item ${note.id === this.currentNoteId ? 'active' : ''}" onclick="app.selectNote(${note.id})">
                <div class="note-title">${note.title}</div>
                <div class="note-preview">${note.content.substring(0, 100)}...</div>
            </div>
        `).join('');
        
        if (this.currentNoteId) {
            this.showNoteEditor();
        }
    }

    selectNote(noteId) {
        this.currentNoteId = noteId;
        this.renderNotes();
    }

    showNoteEditor() {
        const note = this.notes.find(n => n.id === this.currentNoteId);
        const editor = document.getElementById('note-editor');
        
        if (!note || !editor) return;
        
        editor.innerHTML = `
            <div class="editor-header">
                <input type="text" class="form-control" value="${note.title}" onchange="app.updateNoteTitle(${note.id}, this.value)">
            </div>
            <div class="editor-content">
                <textarea placeholder="Start writing..." onchange="app.updateNoteContent(${note.id}, this.value)">${note.content}</textarea>
            </div>
        `;
    }

    createNote() {
        const newNote = {
            id: Date.now(),
            title: 'New Note',
            subject: 'General',
            content: '',
            tags: [],
            dateCreated: new Date().toISOString().split('T')[0]
        };
        
        this.notes.unshift(newNote);
        this.currentNoteId = newNote.id;
        this.saveToStorage();
        this.renderNotes();
    }

    updateNoteTitle(noteId, title) {
        const note = this.notes.find(n => n.id === noteId);
        if (note) {
            note.title = title;
            this.saveToStorage();
            this.renderNotes();
        }
    }

    updateNoteContent(noteId, content) {
        const note = this.notes.find(n => n.id === noteId);
        if (note) {
            note.content = content;
            this.saveToStorage();
        }
    }

    searchNotes() {
        const query = document.getElementById('notes-search')?.value.toLowerCase() || '';
        const filteredNotes = this.notes.filter(note => 
            note.title.toLowerCase().includes(query) || 
            note.content.toLowerCase().includes(query)
        );
        
        const notesList = document.getElementById('notes-list');
        if (notesList) {
            notesList.innerHTML = filteredNotes.map(note => `
                <div class="note-item ${note.id === this.currentNoteId ? 'active' : ''}" onclick="app.selectNote(${note.id})">
                    <div class="note-title">${note.title}</div>
                    <div class="note-preview">${note.content.substring(0, 100)}...</div>
                </div>
            `).join('');
        }
    }

    // Analytics Methods
    renderAnalytics() {
        this.renderWeeklyChart();
        this.renderSubjectChart();
    }

    renderWeeklyChart() {
        const canvas = document.getElementById('weekly-chart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Study Hours',
                    data: [3, 4, 2, 6, 5, 7, 4],
                    backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    renderSubjectChart() {
        const canvas = document.getElementById('subject-chart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Mathematics', 'Chemistry', 'Physics', 'Biology'],
                datasets: [{
                    data: [30, 25, 20, 25],
                    backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    // Quiz Methods
    renderQuizzes() {
        const quizList = document.getElementById('quiz-list');
        if (!quizList) return;
        
        quizList.innerHTML = this.quizzes.map(quiz => `
            <div class="quiz-item">
                <div class="quiz-info">
                    <h3>${quiz.title}</h3>
                    <div class="quiz-meta">${quiz.questions.length} questions</div>
                </div>
                <div class="quiz-actions">
                    <button class="btn btn--primary" onclick="app.startQuiz(${quiz.id})">Take Quiz</button>
                </div>
            </div>
        `).join('');
    }

    createQuiz() {
        const title = prompt('Enter quiz title:');
        if (title) {
            const newQuiz = {
                id: Date.now(),
                title: title,
                questions: []
            };
            this.quizzes.push(newQuiz);
            this.saveToStorage();
            this.renderQuizzes();
        }
    }

    startQuiz(quizId) {
        this.currentQuizId = quizId;
        this.currentQuestionIndex = 0;
        this.quizAnswers = [];
        
        document.getElementById('quiz-list').classList.add('hidden');
        document.getElementById('quiz-taking').classList.remove('hidden');
        
        this.showCurrentQuestion();
    }

    showCurrentQuestion() {
        const quiz = this.quizzes.find(q => q.id === this.currentQuizId);
        if (!quiz) return;
        
        const question = quiz.questions[this.currentQuestionIndex];
        
        document.getElementById('quiz-title').textContent = quiz.title;
        document.getElementById('question-counter').textContent = `Question ${this.currentQuestionIndex + 1} of ${quiz.questions.length}`;
        
        const progress = ((this.currentQuestionIndex + 1) / quiz.questions.length) * 100;
        document.getElementById('quiz-progress').style.width = `${progress}%`;
        
        const container = document.getElementById('question-container');
        container.innerHTML = `
            <div class="question-text">${question.question}</div>
            <div class="answer-options">
                ${question.type === 'multiple' ? 
                    question.options.map((option, index) => `
                        <div class="answer-option" onclick="app.selectAnswer(${index})">${option}</div>
                    `).join('') :
                    `
                        <div class="answer-option" onclick="app.selectAnswer(true)">True</div>
                        <div class="answer-option" onclick="app.selectAnswer(false)">False</div>
                    `
                }
            </div>
        `;
        
        document.getElementById('prev-question').classList.toggle('hidden', this.currentQuestionIndex === 0);
        document.getElementById('next-question').classList.toggle('hidden', this.currentQuestionIndex === quiz.questions.length - 1);
        document.getElementById('finish-quiz').classList.toggle('hidden', this.currentQuestionIndex !== quiz.questions.length - 1);
    }

    selectAnswer(answer) {
        this.quizAnswers[this.currentQuestionIndex] = answer;
        
        document.querySelectorAll('.answer-option').forEach(option => {
            option.classList.remove('selected');
        });
        event.target.classList.add('selected');
    }

    // Utility Methods
    hideModal() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.add('hidden');
        });
    }

    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('hidden');
        }
    }
}

// Initialize the application
const app = new StudyHub();
app.init();